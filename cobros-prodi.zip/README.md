# Cobros — Progreso Digital

App de cobros con Mercado Pago (suscripciones mensuales + pagos únicos).

## Deploy en Vercel

1. Subí esta carpeta a un repo de GitHub (o `vercel deploy` directo).
2. En Vercel → Settings → Environment Variables, agregá:
   - `MP_ACCESS_TOKEN` = tu Access Token de producción (empieza con APP_USR-…)
   - `BACK_URL` (opcional) = URL a donde vuelve el cliente después de pagar
3. Deploy. Listo.

## Endpoints

- `POST /api/crear-cobro` → { nombre, cliente, email?, monto, recurrente } → devuelve link
- `GET /api/estado-cobros` → lista suscripciones y su estado

## Importante

- NUNCA pongas el Access Token en el código. Solo en variables de entorno.
- El estado "authorized" = el cliente cargó la tarjeta y está pagando.
